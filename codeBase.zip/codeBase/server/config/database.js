module.exports = {
  database: 'mongodb://localhost:27017/App',
  secret: 'yoursecret'
}
