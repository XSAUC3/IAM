import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-types',
  templateUrl: './resource-types.component.html',
  styleUrls: ['./resource-types.component.css']
})
export class ResourceTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
