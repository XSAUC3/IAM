import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrative-users',
  templateUrl: './administrative-users.component.html',
  styleUrls: ['./administrative-users.component.css']
})
export class AdministrativeUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
